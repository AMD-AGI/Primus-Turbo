# Performance trend (append-only)

Primary metric: geomean step_us (sum of the four fused ops, us, lower is better) over the n4 quick set
(5 GQA shapes); "all-7" adds the two CP8 shapes when that round ran them. Per-op columns: max fused / floor
over the n4 shapes (diagnostic). vs Baseline: change of the n4 geomean vs round 1 (negative = faster).

| Round | Status | Description | n4 geomean step_us | all-7 geomean | max fwd QKV / fl | max fwd o / fl | max bwd o / fl | max bwd QKV / fl | MLA guard fwd/bwd | vs Baseline | Key Finding |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | BASELINE | c8b054cc (MLA R2-R6) | 5228.1 | 4093.8 | 1.06 | 1.47 | 1.21 | 1.58 | 1994 / 3154 | — | bwd QKV and GLM fwd o_proj furthest from the floor; noise ~1 % |
| 2 | ROLLBACK | fwd QKV GemmA2A BM=256 always | 5224.4 | 4081.5 | 1.03 | 1.47 | 1.24 | 1.59 | 2014 / 3149 | -0.30 % | wins at >= 3.9 waves of 256-row tiles (GLM CP8 1.36 -> 1.18), loses at 2.2-2.8 (Qwen3-30B +4 %, MiniMax CP8 +8 %) |
| 3 | ACCEPT (dff7cc51) | fwd QKV BM=256 from 3 waves of 256-row tiles | 5198.1 | 4059.0 | 1.02 | 1.47 | 1.22 | 1.59 | 1994 / 3142 | -0.85 % | GLM CP8 fwd QKV 1.36 -> 1.17, GLM 128K 0.95; no shape regresses |

Note: the max fused/floor columns are over the n4 shapes; CP8 ratios are in each round's summary.
