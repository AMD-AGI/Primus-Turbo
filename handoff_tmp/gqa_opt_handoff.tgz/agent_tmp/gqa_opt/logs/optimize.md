# GQA Ulysses fused-op campaign — optimization log (append-only)

## 2026-11-16 12:03 UTC — setup
- Node smci355-ccs-aus-m11-13 (8 x MI355X), container xmp_pr1275 (tasimage/primus:pr-1275).
- Primus-Turbo at ~/Turbo_gqa (cursor/gqa-ulysses-opt-43f1 @ c8b054cc), built in place for gfx950.
- Primus at ~/Primus_gqa (cursor/ulysses-mla-gqa-proxy-configs-43f1), read-only.
- No historical tips file exists for this op.

## Round 1 — BASELINE
- Smoke 16K (Qwen3-30B, GLM): PASS, fused within 3 % of baseline/ except GLM bwd o_proj (-7 %, this node's
  hipBLASLt is ~8 % faster too).
- Quick set (n4, twice) + CP8: n4 geomean 5228.1 / 5230, all-7 4093.8, all PASS; MLA guard fwd 1994 bwd 3154.
- Details: rounds/round-1/summary.md.

## Phase 0 conclusions (2026-11-16)

Full report: `profiles/phase0_report.md`. Summary: fwd o_proj loss = BM=128 tile cfg (1.22-1.31x hip) + ~25% push-concurrency slowdown + tail 43-165us; bwd QKV loss = dgrad tiles paced by arrival (23-30% of kernel), tile speed fine; fwd QKV BM=256 measured -3..-12%; outside fused ops ~3-5% of layer (RoPE, torch rms_norm bwd, qk-norm, dW accumulation), attention 73-78%.

## Round 2 — ROLLBACK (fwd QKV BM=256 always): Qwen3-30B +4 %, MiniMax CP8 +8 %.
## Round 3 — ACCEPT dff7cc51 (fwd QKV BM=256 from 3 waves): all-7 -0.85 %.
## Round 4 (in progress, 2026-11-17) — see handoff/HANDOFF.md
