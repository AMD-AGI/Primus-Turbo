# 阶段 0 定位结论（2026-11-16 12:50 UTC，MI355X，32K）

数据：`profiles/phase0a/*.txt`（A2AGemm / GemmA2A kernel 内 trace），`profiles/phase0b/*.txt|json`（单层 profile）。
拆分方法（A2AGemm，`trace_a2a_gemm.py` 新增 breakdown）：kernel 时长 × 256 CU =
hipBLASLt 等效工作 + tile 配置损失（纯 tile − hipBLASLt）+ tile 内等待（其余 tile 时间）+ wgrad 同理
+ push CU + 尾巴（最后一次 256 CU 全忙之后的空闲）+ 中间空隙；单位换算成 us（CU-us / 256）。
"纯 tile"取数据开工时已全部到达的 tile 中位数；`dbg_serial`（临时调试开关）让 GEMM block 等全部数据到达后
才开工，得到不受 push 并发干扰的纯 tile 时间。trace 本身让 kernel 慢 1–10 %，只看比例。

## A2AGemm fwd o_proj（默认 BM=128，in-step push，32 pusher）

| 形状 | kernel | hipBLASLt | tile 配置 + 并发 | K walk 等待 | push CU | 尾巴 |
|---|---|---|---|---|---|---|
| GLM CP4 | 1510 | 772 | 492 | 44 | 106 | 86 |
| GLM CP8 | 746 | 412 | 201 | 17 | 30 | 82 |
| Qwen3-235B CP4 | 840 | 422 | 216 | 61 | 71 | 58 |
| MiniMax CP4 | 542 | 257 | 181（含等待） | — | 53 | 43 |

- (a) tile 配置：串行模式（无并发 push）纯 tile / hipBLASLt：BM=128 **1.22–1.31**，BM=256 **1.02–1.06**
  （GLM CP8 1.15）。正常模式 BM=128 纯 tile 是 1.49–1.64：**和 push 并发让 tile 再慢 ~25 %**
  （GLM CP4：配置 241 us + 并发 251 us）。
- (b) push CU：32 个 pusher = 12.5 % CU，折合 30–106 us（kernel 的 4–10 %）。
- (c) 等待：BM=128 时小（17–61 us）；BM=256 时 tile 第一波都在等数据（GLM CP4 BM=256：配置 46 us，
  等待 + 并发 ~375 us）。
- (d) 尾巴：BM=128 43–86 us，BM=256 94–165 us；GLM CP8 串行模式 BM=256 尾巴 227 us
  （320 tile / 256 CU = 1.25 波）。
- GLM CP8 是 GEMM 主导：push 260 us 就结束，kernel 746 us。

## A2AGemm bwd QKV（BM=256，wgrad 放后）

| 形状 | kernel | hipBLASLt | dgrad 等待 | wgrad 配置 | wgrad 等待 | push CU | 尾巴 |
|---|---|---|---|---|---|---|---|
| GLM CP4 | 2593 | 1748 | 355 | 223 | 16 | 137 | 102 |
| GLM CP8 | 1201 | 972 | 167 | −28 | 0 | 34 | 43 |
| MiniMax CP4 | 1154 | 645 | 333 | 7 | 18 | 40 | 104 |
| Qwen3-235B CP4 | 1430 | 897 | 264 | 85 | 0 | 78 | 98 |

- (a) dgrad 256×256 tile 数据已到达时 = hipBLASLt 的 **0.96–1.04**，不是问题；wgrad tile 1.02–1.25
  （全部挤在最后同时跑时 GLM 1.43、Qwen3-235B 1.36）。
- (c) **主要损失是调度**：dgrad tile 先开工，在 push 阶段被到达速度拖住（264–355 us，kernel 的 23–30 %）。
  wgrad 放前面（`wgrad_at=0`）时同样的损失转到 wgrad（405–785 us，更差）。dgrad 和 wgrad 都消费交换的数据，
  wgrad 要对整个 M 规约，放前面会一直占着 CU 等最后的行。
- (b) push CU 40–137 us（3.5–5 %）；(d) 尾巴 98–104 us（MiniMax 384 个 wgrad tile = 1.5 波）。

## GemmA2A（`trace_gemm_a2a.py --op fwd_qkv|bwd_o`，untraced 时间）

| 形状 | fwd QKV BM=128 | fwd QKV BM=256 | tile/hip 128 → 256 |
|---|---|---|---|
| GLM CP4 | 1278 | 1230 (−3.8 %) | 1.20 → 1.01 |
| GLM CP8 | 634 | 561 (−11.5 %) | 1.14 → 0.86 |
| MiniMax CP4 | 752 | 721 (−4.1 %) | 1.09 → 0.95 |
| Qwen3-235B CP4 | 821 | 798 (−2.8 %) | 1.17 → 0.96 |

- fwd QKV 的 BM=128 让 GEMM 慢 9–20 %；GLM CP4/CP8 是 GEMM 主导，MiniMax / Qwen3-235B 是 pull（链路）主导。
- bwd o_proj（BM=256）tile 0.92–1.12；GEMM tile 结束后 pull 还要 166–252 us（链路主导，pull 在第一波
  GEMM 之后才开始，约晚 70 us）。

## 阶段 0b：单层（GQA attention 块 fwd+bwd，n=4，32K，`bench_gqa_layer.py`）

| 模型 | 层 fwd+bwd（融合 / 串行） | attention | 融合算子 | 其他 |
|---|---|---|---|---|
| GLM-4.7 | 33.5 / 37.7 ms | 25.8 ms (77 %) | 6.78 ms | ~0.97 ms |
| Qwen3-30B | 9.20 / 10.68 ms | 7.06 ms (78 %) | 1.57 ms | ~0.44 ms |
| MiniMax-M2.5 | 17.3 / 19.3 ms | (profiler 丢事件) | 2.23 ms | ~0.60 ms |
| Qwen3-235B | 19.0 / 21.6 ms | 14.0 ms (73 %) | 4.27 ms | ~0.83 ms |

融合算子之外（占融合算子时间的 14–28 %，占层的 3–5 %）：
1. RoPE（TE 融合 kernel，q、k 各一次 fwd + bwd）：GLM 394、Qwen3-235B 297、Qwen3-30B 141 us。
   MiniMax 用的是 Megatron 的非融合 RoPE（partial rotary，`apply_rope_fusion: false`）：cat 142 us +
   逐元素 ~230 us。
2. 输入 RMSNorm：patch 用 `F.rms_norm`（torch 原生 kernel），bwd 很慢：GLM fwd 33 + bwd 130 + gamma 65 us。
3. qk-norm（TE RMSNorm，Qwen3 / MiniMax）：Qwen3-235B ~230 us，Qwen3-30B ~150 us。
4. 权重梯度累加：融合算子返回新的 dW，`param.grad` / Megatron `main_grad` 再加一次（GLM 3 次 add 130 us）。
5. `.contiguous()` / view 引起的拷贝：融合路径上没有（b=1）。
attention 占层的 73–78 %，融合算子 17–22 %。

## 阶段 1 方向（按收益排序）
1. fwd QKV GemmA2A BM=256（实测 −3 ~ −12 %，最简单，先做）。
2. fwd o_proj：BM=256（GEMM 时间 −20 %）+ 处理第一波等数据和最后一波量化（split-K / stream-K 最后一波）；
   `gemm_bound` 判定按 kernel 内 GEMM 实际速度修正。
3. bwd QKV 调度：dgrad 被到达速度拖住 23–30 %（例如本 rank 数据先 push，用本地 source 的 wgrad tile 填
   push 阶段的空闲 CU；或 wgrad 按 M 分段）。
4. 并发干扰（push 时 tile 慢 ~25 %）：待查（HBM / L2 争用）。
5. 融合算子之外（需要改 Primus，先找你确认）：RoPE / qk-norm 融进 pull / push、输入 RMSNorm 换 TE kernel、
   wgrad 直接累加进 main_grad、MiniMax 打开 RoPE 融合。
