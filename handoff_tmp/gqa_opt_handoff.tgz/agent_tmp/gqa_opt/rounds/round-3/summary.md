# Round 3 — ACCEPT: fwd QKV GemmA2A BM=256 from 3 waves of 256-row tiles (2026-11-16 13:04 UTC)

## Hypothesis
Round 2: 256-row tiles win at >= 3.5 waves, lose at 2-2.5 waves (first wave the pulls wait behind and the
last-wave tail double).

## Single change
`_qkv_gemm_a2a_forward`: `BM = 256 if ceil(M/256) * ceil(N/256) >= 3 * num_cus else 128`.

## Correctness
`test_ulysses_fused_a2a.py --quick` and full (n=8): all cases passed. `check_mla_exit.py --long` (n=4):
all cases passed. Quick-set check PASS on all 7 shapes.

## Results (`artifacts/quick_cp8`, vs round 1)
| shape | n | step | vs base | fwd_qkv/fl | fwd_o/fl | bwd_o/fl | bwd_qkv/fl |
|---|---|---|---|---|---|---|---|
| glm-4.7:32768 | 4 | 6815 | -0.5 % | 1.01 | 1.47 | 1.07 | 1.39 |
| glm-4.7:131072 | 4 | 27433 | -1.3 % | 0.95 | 1.43 | 1.22 | 1.48 |
| minimax-m2.5:32768 | 4 | 3047 | -0.8 % | 1.02 | 1.09 | 1.17 | 1.59 |
| qwen3-235b-a22b:32768 | 4 | 4028 | -0.2 % | 1.01 | 1.27 | 1.18 | 1.55 |
| qwen3-30b-a3b:32768 | 4 | 1654 | -0.3 % | 0.94 | 1.00 | 1.00 | 1.06 |
| glm-4.7:32768 | 8 | 3405 | -2.6 % | 1.17 | 1.80 | 1.10 | 1.23 |
| minimax-m2.5:32768 | 8 | 1405 | -0.3 % | 1.14 | 1.58 | 1.00 | 1.71 |

n4 geomean 5198.1, all-7 4059.0 (-0.85 %). MLA guard fwd 1994 / bwd 3142.

## Decision
ACCEPT, committed locally as dff7cc51 (not pushed).

## Next direction
fwd o_proj (A2AGemm): BM / num_push per shape and the last-wave tail (round 4).
