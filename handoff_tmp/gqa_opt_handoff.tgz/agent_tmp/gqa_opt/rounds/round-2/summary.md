# Round 2 — ROLLBACK: fwd QKV GemmA2A BM=256 for every shape (2026-11-16 12:58 UTC)

## Hypothesis
Phase 0a: GemmA2A fwd QKV 128-row tiles run 1.09-1.20x hipBLASLt, 256-row ones 0.86-1.01x; untraced
GLM CP4 1278 -> 1230, GLM CP8 634 -> 561, MiniMax 752 -> 721, Qwen3-235B 821 -> 798.

## Single change
`_qkv_gemm_a2a_forward`: `BM=256` added to the launch defaults (was the kernel default 128).

## Correctness
`test_ulysses_fused_a2a.py --quick` (n=8): all cases passed. Quick-set check PASS on all 7 shapes.

## Results (`artifacts/quick_cp8`, vs round 1)
| shape | n | fwd QKV r1 -> r2 (us) | fused/floor | step | vs base |
|---|---|---|---|---|---|
| glm-4.7:32768 | 4 | 1261 -> 1229 | 1.04 -> 1.01 | 6831 | -0.2 % |
| glm-4.7:131072 | 4 | 4968 -> 4525 | 1.05 -> 0.95 | 27522 | -1.0 % |
| minimax-m2.5:32768 | 4 | 746 -> 723 | 1.06 -> 1.03 | 3069 | -0.1 % |
| qwen3-235b-a22b:32768 | 4 | 822 -> 798 | 1.05 -> 1.01 | 4025 | -0.3 % |
| qwen3-30b-a3b:32768 | 4 | 428 -> 446 | 0.94 -> 0.98 | 1676 | **+1.0 %** |
| glm-4.7:32768 | 8 | 638 -> 557 | 1.36 -> 1.18 | 3401 | -2.6 % |
| minimax-m2.5:32768 | 8 | 253 -> 274 | 1.13 -> 1.22 | 1426 | **+1.2 %** |

n4 geomean 5224.4 (-0.07 %), all-7 4081.5 (-0.30 %). MLA guard fwd 2014 / bwd 3149 (does not use this
kernel path; fwd +1 % is within noise).

## Decision
ROLLBACK: Qwen3-30B (must not regress) fwd QKV +4 %, MiniMax CP8 +8 %.

## Attribution
Improves where the 256-row tiles make >= 3.9 waves (GLM CP4 1792 tiles, GLM CP8 896, MiniMax CP4 1024,
Qwen3-235B 1152 over 232 GEMM CUs); regresses at 2.2-2.8 waves (MiniMax CP8 512, Qwen3-30B 640). With few
waves the doubled first-wave time (pulls start after the first tiles retire) and the last-wave tail outweigh
the faster tiles. The gemm/a2a ratio does not separate them (MiniMax CP8 0.73 regresses, MiniMax CP4 0.43
improves).

## Next direction
Round 3: BM=256 only when the 256-row tiles make >= 3 waves (`tiles >= 3 * num_cus`).

## Real-training transfer check
- Bucket: shape-level heuristic; e2e check at the end of the phase.
