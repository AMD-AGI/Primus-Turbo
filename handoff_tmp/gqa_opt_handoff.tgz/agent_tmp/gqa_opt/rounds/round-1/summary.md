# Round 1 — BASELINE (branch cursor/gqa-ulysses-opt-43f1 @ c8b054cc, 2026-11-16 12:03 UTC)

## Hypothesis
None: baseline. Tools first run on GPU (gqa_quick_bench.py, score_gqa.py, run_quick.sh).

## Single change
None (kernel code = c8b054cc, MLA campaign R2-R6 included).

## Environment check (step 1)
- 8 x MI355X (256 CU), container `tasimage/primus:pr-1275`: torch 2.14.0+rocm10.1.0, flydsl 0.3.4.1, amd-aiter 0.1.24.post1.
- C++ extension built in place (`setup.py build_ext --inplace`, GPU_ARCHS=gfx950); run with PYTHONPATH=repo.
- Smoke `--shapes qwen3-30b-a3b:16384 glm-4.7:16384` (n=4): check PASS both.
  vs baseline/ fused column: Qwen3-30B 237/214/217/279 vs 236/213/223/279 (<=3 %); GLM 671/808/858/1311 vs
  670/792/920/1342: all within 2 % except GLM bwd o_proj -7 %. hipBLASLt is ~8 % faster on this node
  (GLM 16K gemm 380 vs 415, wgrad 403 vs 440), so ratios vs floor stay comparable; no environment issue.

## Results (us, max over ranks, median of 30; fused / floor (ratio); floor measured in the same run)
Run `artifacts/quick_cp8` (CP8=1 --unfused). A second n4 run (`artifacts/quick`) agrees within ±0.8 % per
shape (geomean +0.04 %): noise floor ~1 %.

| shape | n | fwd QKV | fwd o_proj | bwd o_proj | bwd QKV | step | floor | unfused |
|---|---|---|---|---|---|---|---|---|
| glm-4.7:32768 | 4 | 1261 / 1207 (1.04) | 1529 / 1039 (1.47) | 1623 / 1523 (1.07) | 2435 / 1742 (1.40) | 6847 | 5512 | 10864 |
| glm-4.7:131072 | 4 | 4968 / 4747 (1.05) | 5808 / 4079 (1.42) | 7212 / 5943 (1.21) | 9813 / 6639 (1.48) | 27801 | 21408 | 43775 |
| minimax-m2.5:32768 | 4 | 746 / 704 (1.06) | 593 / 536 (1.11) | 623 / 535 (1.16) | 1109 / 702 (1.58) | 3072 | 2477 | 4967 |
| qwen3-235b-a22b:32768 | 4 | 822 / 787 (1.05) | 884 / 704 (1.26) | 958 / 819 (1.17) | 1371 / 892 (1.54) | 4036 | 3202 | 6506 |
| qwen3-30b-a3b:32768 | 4 | 428 / 454 (0.94) | 369 / 374 (0.99) | 375 / 373 (1.01) | 487 / 455 (1.07) | 1659 | 1655 | 2958 |
| glm-4.7:32768 | 8 | 638 / 470 (1.36) | 749 / 413 (1.82) | 906 / 820 (1.10) | 1201 / 970 (1.24) | 3494 | 2673 | 4699 |
| minimax-m2.5:32768 | 8 | 253 / 223 (1.13) | 272 / 174 (1.56) | 285 / 284 (1.00) | 599 / 347 (1.72) | 1409 | 1029 | 2121 |

- geomean step_us: n4 (5 shapes) **5228.1** (run 1) / 5230 (run 2); all 7 shapes **4093.8**. All PASS.
- MLA exit guard (deepseek-v3 32K n=4): fwd 1994 / 1976 us, bwd 3154 / 3150 us, PASS.

## Decision
BASELINE.

## Attribution
Largest gaps to the floor: bwd QKV everywhere (1.40-1.72, the wgrad + dgrad A2AGemm), fwd o_proj on GLM
(1.42-1.82) and Qwen3-235B (1.26), fwd QKV at CP8 (1.36). Qwen3-30B sits on the floor.

## Next direction
Phase 0a: trace-based split of the losses into tile config / push CUs / waits / tail (no kernel change).

## Real-training transfer check
- Bucket: n/a (baseline)
