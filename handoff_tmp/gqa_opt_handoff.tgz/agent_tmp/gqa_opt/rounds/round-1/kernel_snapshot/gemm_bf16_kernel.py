###############################################################################
# SPDX-License-Identifier: Apache-2.0
#
# Copyright (c) 2025, Advanced Micro Devices, Inc. All rights reserved.
# Copyright (c) 2025 FlyDSL Project Contributors
#
# Adapted from FlyDSL (https://github.com/ROCm/FlyDSL)
# Modified by the Primus-Turbo team.
#
# This file is distributed under the Apache License 2.0 (see LICENSE-APACHE),
# not the MIT license that covers the rest of Primus-Turbo (see LICENSE).
###############################################################################

# MegaMoE-owned snapshot of the shared FlyDSL BF16 GEMM tile as of f6d5ab68
# (last known-good before ed8d7af4 / #486 rebuilt the shared tile around Mfma16x16x32).
# Mega MoE imports from here so later flydsl/grouped_gemm changes cannot silently
# change MegaMoE numerical behaviour.
#
"""Primus-Turbo dense BF16 GEMM kernel (FlyDSL)."""

import flydsl.expr as fx
from flydsl._mlir.dialects import llvm as _llvm
from flydsl.compiler.ast_rewriter import ASTRewriter
from flydsl.expr import arith, const_expr, range_constexpr, rocdl
from flydsl.expr.typing import Vector as Vec

from primus_turbo.flydsl.gemm.gemm_bf16_kernel import _quad_col_conds
from primus_turbo.flydsl.mega.bf16.gemm_helper import (
    compute_global_swizzle_bf16,
    compute_global_swizzle_bf16_row_col,
    store_band_merged16,
)
from primus_turbo.flydsl.utils.buffer_ops import buffer_load, create_buffer_resource
from primus_turbo.flydsl.utils.gemm_helper import (
    BLOCK_K,
    G2SLoader,
    Mfma16x16x32,
    S2RLoader16x16Bf16,
    S2RLoaderTr16x32Bf16Wide,
    StoreCBf16,
    compute_global_swizzle_nn_bf16_wide,
    emit_if_then,
    make_fp16_bf16_buffer_tensor,
    wait_barrier,
    xcd_remap_pid,
)
from primus_turbo.flydsl.utils.prims import ceildiv

# isort: on


def _make_shared_storage(BLOCK_M, BLOCK_N, chunk_stride=1024, num_lds_row_idx_entries=0):
    a_lds_size = (BLOCK_M // 16) * chunk_stride // 2
    b_lds_size = (BLOCK_N // 16) * chunk_stride // 2
    assert 8 * (a_lds_size + b_lds_size) + 4 * num_lds_row_idx_entries <= 163840, "exceeds the 160 KiB LDS"

    @fx.struct
    class SharedStorage:
        A_lds_cur_0: fx.Array[fx.BFloat16, a_lds_size, 16]
        A_lds_cur_1: fx.Array[fx.BFloat16, a_lds_size, 16]
        A_lds_next_0: fx.Array[fx.BFloat16, a_lds_size, 16]
        A_lds_next_1: fx.Array[fx.BFloat16, a_lds_size, 16]
        B_lds_cur_0: fx.Array[fx.BFloat16, b_lds_size, 16]
        B_lds_cur_1: fx.Array[fx.BFloat16, b_lds_size, 16]
        B_lds_next_0: fx.Array[fx.BFloat16, b_lds_size, 16]
        B_lds_next_1: fx.Array[fx.BFloat16, b_lds_size, 16]
        if num_lds_row_idx_entries:
            lds_row_idx: fx.Array[fx.Int32, num_lds_row_idx_entries, 16]

    return SharedStorage


def _make_a_g2s(a_div, a_gl_offsets, a_row_idx, lane_id, wave_id, K, n_steps, LDS_BLOCK_M):
    """A loaders for the two LDS halves; ``a_row_idx`` maps the tile's local rows to rows of A."""
    if a_row_idx is None:
        a_g2s = G2SLoader(a_div, a_gl_offsets, n_steps, fx.BFloat16.ir_type, wave_id)
        return a_g2s, a_g2s
    row_idx_resource = create_buffer_resource(a_row_idx, num_records_bytes=2 * LDS_BLOCK_M * 4)
    row_cols = compute_global_swizzle_bf16_row_col(lane_id, wave_id, n_steps)
    return tuple(
        G2SLoader(
            a_div,
            [
                buffer_load(row_idx_resource, row + half * LDS_BLOCK_M, vec_width=1, dtype=fx.T.i32)
                * fx.Int32(K)
                + col
                for row, col in row_cols
            ],
            n_steps,
            fx.BFloat16.ir_type,
            wave_id,
        )
        for half in (0, 1)
    )


class _KExt:
    """The second operand pair of a ``k_ext`` K loop (see ``dense_mma_pipeline_bf16``)."""

    def __init__(self, a_g2s, b_g2s, a_base, b_base, num_chunks):
        self.a_g2s, self.b_g2s, self.a_base, self.b_base = a_g2s, b_g2s, a_base, b_base
        self.num_chunks = num_chunks


@ASTRewriter.transform
def dense_mma_pipeline_bf16(
    lds,
    a_g2s,
    b_g2s,
    a_s2r,
    b_s2r,
    mfma,
    store_c,
    A0_gl_offset,
    A1_gl_offset,
    B0_gl_offset,
    B1_gl_offset,
    a_k_step,
    b_k_step,
    block_m,
    block_n,
    wave_m,
    wave_n,
    K,
    BLOCK_M,
    BLOCK_N,
    nt_vmcnt,
    pair_cols=False,
    pair_tiles=False,
    quad_conds=None,
    half_n=False,
    n_tiles_a=None,
    n_tiles_b=None,
    wave_hi=None,
    col_safe=False,
    persistent=False,
    merge_tile_pairs=False,
    k_seg=None,
    k_ext=None,
):
    """Shared 4-quadrant pipelined MMA loop and store epilogue for the fixed-K bf16 tile.
    Keyword flags select the feed and epilogue variants a ragged N needs; each is explained at
    the site that consumes it.  Every caller feeds ``Mfma16x16x32``.

    ``k_seg`` (optional) walks K in segments of ``k_seg.seg_len`` chunks: chunk ``c`` reads K chunk
    ``k_seg.chunk_base(seg) + c % seg_len`` of ``seg = c // seg_len``, and every wave runs
    ``k_seg.wait(seg)`` before its first A load of a segment (each wave orders its own loads).
    ``k_seg.num_chunks`` (optional) walks that many chunks instead of ``K // BLOCK_K``; ``K`` stays
    the operands' row stride.

    ``k_ext`` (optional) appends ``k_ext.num_chunks`` chunks from a second operand pair into the
    same accumulators: its loaders ``a_g2s`` (two halves) / ``b_g2s`` from offsets ``a_base`` /
    ``b_base`` (two halves each), with this call's K steps."""
    MFMA_MN = 16
    K1_ITERS = K // BLOCK_K if getattr(k_seg, "num_chunks", None) is None else k_seg.num_chunks
    K_ITERS = K1_ITERS + (0 if k_ext is None else k_ext.num_chunks)
    assert K_ITERS >= 2, f"K_ITERS={K_ITERS} too small; need K >= {2 * BLOCK_K}"
    N_TILES_A = BLOCK_M // 128 if n_tiles_a is None else n_tiles_a
    N_TILES_B = BLOCK_N // 256 if n_tiles_b is None else n_tiles_b
    WAVE_HI = wave_m if wave_hi is None else wave_hi
    N_ACCUMS = N_TILES_A * N_TILES_B
    LDS_BLOCK_M = BLOCK_M // 2
    LDS_BLOCK_N = BLOCK_N // 2
    a_g2s0, a_g2s1 = a_g2s
    # Drain counts are stated in loads still in flight, not derived from the block shape.
    N_LDS_STEPS_A = a_g2s0.n_load_steps
    N_LDS_STEPS_B = b_g2s.n_load_steps

    a_cur0 = lds.A_lds_cur_0
    a_cur1 = lds.A_lds_cur_1
    a_next0 = lds.A_lds_next_0
    a_next1 = lds.A_lds_next_1
    b_cur0 = lds.B_lds_cur_0
    b_cur1 = lds.B_lds_cur_1
    b_next0 = lds.B_lds_next_0
    b_next1 = lds.B_lds_next_1

    PRED = quad_conds is not None
    if const_expr(k_seg is None):
        seg_len, seg_base = K1_ITERS, [0]
    else:
        seg_len = k_seg.seg_len
        assert K1_ITERS % seg_len == 0
        seg_base = [k_seg.chunk_base(seg) for seg in range_constexpr(K1_ITERS // seg_len)]

    def a_off(base, c):
        return base + (seg_base[c // seg_len] + c % seg_len) * a_k_step

    def b_off(base, c):
        return base + (seg_base[c // seg_len] + c % seg_len) * b_k_step

    def a_load(half, dst, c):
        if const_expr(c >= K1_ITERS):
            k_ext.a_g2s[half].load(dst, k_ext.a_base[half] + (c - K1_ITERS) * a_k_step)
        else:
            (a_g2s0, a_g2s1)[half].load(dst, a_off((A0_gl_offset, A1_gl_offset)[half], c))

    def b_load(half, dst, c):
        if const_expr(c >= K1_ITERS):
            k_ext.b_g2s.load(dst, k_ext.b_base[half] + (c - K1_ITERS) * b_k_step)
        else:
            b_g2s.load(dst, b_off((B0_gl_offset, B1_gl_offset)[half], c))

    def k_wait(c):
        if const_expr(k_seg is not None and c < K1_ITERS and c % seg_len == 0):
            k_seg.wait(c // seg_len)

    c00_frag = [mfma.zero_value] * N_ACCUMS
    c01_frag = [mfma.zero_value] * N_ACCUMS
    c10_frag = [mfma.zero_value] * N_ACCUMS
    c11_frag = [mfma.zero_value] * N_ACCUMS
    if const_expr(PRED):
        # Memrefs, not SSA: a predicated accumulator would phi out of every branch at register cost.
        acc = [
            [fx.make_rmem_tensor(fx.make_layout(mfma.acc_len, 1), fx.Float32) for _ in range(N_ACCUMS)]
            for _ in range_constexpr(4)
        ]
        for regs in acc:
            for reg in regs:
                fx.memref_store_vec(mfma.zero_value, reg)
        conds = [quad_conds[0, 0], quad_conds[0, 1], quad_conds[1, 0], quad_conds[1, 1]]

    def _mma(q, frag, a, b):
        """One accumulator quadrant, skipped whole when its output columns are masked."""
        if const_expr(not PRED):
            return mfma.call(a, b, frag)

        def _do():
            c = [Vec(fx.memref_load_vec(reg)) for reg in acc[q]]
            c = mfma.call(a, b, c)
            for t in range_constexpr(N_ACCUMS):
                fx.memref_store_vec(c[t], acc[q][t])

        emit_if_then(conds[q], _do)
        return frag

    B1_STEPS = N_LDS_STEPS_B
    LOOP_DRAIN = 2 * N_LDS_STEPS_A + N_LDS_STEPS_B
    ITER_DRAIN = nt_vmcnt
    if const_expr(half_n):
        B1_STEPS = 0
        LOOP_DRAIN = N_LDS_STEPS_A + N_LDS_STEPS_B
        # ``nt_vmcnt`` counts the full body's issue stream, so a narrowed feed retires a different load.
        ITER_DRAIN = N_LDS_STEPS_A

    b_load(0, b_cur0, 0)
    k_wait(0)
    a_load(0, a_cur0, 0)
    if const_expr(not half_n):
        b_load(1, b_cur1, 0)
    a_load(1, a_cur1, 0)

    # One tile per WG: only the high half has to wait here, and the divergence is harmless
    # because the WG ends right after. Inside a persistent tile loop it is not -- the next
    # tile's g2s would overrun LDS the other waves are still reading -- so every wave stops.
    # ``persistent="staggered"`` keeps the one-WG offset and realigns at the tile's end instead.
    if const_expr(persistent is True):
        rocdl.s_barrier()
    elif WAVE_HI == 1:
        rocdl.s_barrier()
    wait_barrier(N_LDS_STEPS_A + B1_STEPS)

    b_load(0, b_next0, 1)
    k_wait(1)
    a_load(0, a_next0, 1)
    if const_expr(not half_n):
        b_load(1, b_next1, 1)

    # K_ITERS == 2 skips the main loop, leaving the tail's b_next0 read with no vmcnt wait.
    # B1_STEPS lands it either way: full-N leaves b_next1 behind it, half-N issues nothing after.
    wait_barrier(B1_STEPS if K_ITERS == 2 else N_LDS_STEPS_A + N_LDS_STEPS_B + B1_STEPS)

    for k in range_constexpr(K_ITERS - 2):
        b0_frag = b_s2r.load(b_cur0)
        a0_frag = a_s2r.load(a_cur0)
        a_load(1, a_next1, (k + 1))
        rocdl.s_barrier()

        rocdl.sched_barrier(0)
        c00_frag = _mma(0, c00_frag, a0_frag, b0_frag)
        rocdl.sched_barrier(0)
        rocdl.s_barrier()

        if const_expr(not half_n):
            b1_frag = b_s2r.load(b_cur1)
        b_load(0, b_cur0, (k + 2))
        if const_expr(not half_n):
            rocdl.s_barrier()

        if const_expr(not half_n):
            rocdl.sched_barrier(0)
            c01_frag = _mma(1, c01_frag, a0_frag, b1_frag)
            rocdl.sched_barrier(0)
            rocdl.s_barrier()

        a1_frag = a_s2r.load(a_cur1)
        k_wait(k + 2)
        a_load(0, a_cur0, (k + 2))
        rocdl.s_barrier()

        rocdl.sched_barrier(0)
        c10_frag = _mma(2, c10_frag, a1_frag, b0_frag)
        rocdl.sched_barrier(0)
        if const_expr(not half_n):
            rocdl.s_barrier()
            b_load(1, b_cur1, (k + 2))
        wait_barrier(LOOP_DRAIN)

        if const_expr(not half_n):
            rocdl.sched_barrier(0)
            c11_frag = _mma(3, c11_frag, a1_frag, b1_frag)
            rocdl.sched_barrier(0)
            rocdl.s_barrier()

        if const_expr(ITER_DRAIN >= 0):
            _llvm.inline_asm(
                res=None,
                operands_=[],
                asm_string=f"s_waitcnt vmcnt({ITER_DRAIN})",
                constraints="",
                has_side_effects=True,
            )
        a_cur0, a_next0 = a_next0, a_cur0
        a_cur1, a_next1 = a_next1, a_cur1
        b_cur0, b_next0 = b_next0, b_cur0
        b_cur1, b_next1 = b_next1, b_cur1

    k = K_ITERS - 2
    b0_frag = b_s2r.load(b_cur0)
    a0_frag = a_s2r.load(a_cur0)
    rocdl.s_barrier()
    rocdl.sched_barrier(0)
    c00_frag = _mma(0, c00_frag, a0_frag, b0_frag)
    rocdl.sched_barrier(0)
    rocdl.s_barrier()

    if const_expr(not half_n):
        b1_frag = b_s2r.load(b_cur1)
        rocdl.s_barrier()
        rocdl.sched_barrier(0)
        c01_frag = _mma(1, c01_frag, a0_frag, b1_frag)
        rocdl.sched_barrier(0)
        rocdl.s_barrier()

    a1_frag = a_s2r.load(a_cur1)
    rocdl.s_barrier()
    rocdl.sched_barrier(0)
    c10_frag = _mma(2, c10_frag, a1_frag, b0_frag)
    rocdl.sched_barrier(0)
    rocdl.s_barrier()

    b0_frag = b_s2r.load(b_next0)
    a_load(1, a_next1, (k + 1))
    if const_expr(not half_n):
        rocdl.s_barrier()
        rocdl.sched_barrier(0)
        c11_frag = _mma(3, c11_frag, a1_frag, b1_frag)
        rocdl.sched_barrier(0)
        rocdl.s_barrier()

    a_cur0, a_next0 = a_next0, a_cur0
    a_cur1, a_next1 = a_next1, a_cur1
    b_cur0, b_next0 = b_next0, b_cur0
    b_cur1, b_next1 = b_next1, b_cur1

    # Drain before the read: the tail is the first consumer of the last iteration's refill.
    wait_barrier(0)
    a0_frag = a_s2r.load(a_cur0)
    rocdl.sched_barrier(0)
    c00_frag = _mma(0, c00_frag, a0_frag, b0_frag)
    rocdl.sched_barrier(0)
    rocdl.s_barrier()

    if const_expr(not half_n):
        b1_frag = b_s2r.load(b_cur1)
        rocdl.s_barrier()
        rocdl.sched_barrier(0)
        c01_frag = _mma(1, c01_frag, a0_frag, b1_frag)
        rocdl.sched_barrier(0)
        rocdl.s_barrier()

    wave_n_offset = wave_n * (N_TILES_B * MFMA_MN)
    wave_m_offset = wave_m * (N_TILES_A * MFMA_MN)
    base_row = block_m * BLOCK_M + wave_m_offset
    base_col = block_n * BLOCK_N + wave_n_offset

    if const_expr(PRED):
        c00_frag = [Vec(fx.memref_load_vec(reg)) for reg in acc[0]]
        # Half 1 never accumulated, so its quadrants keep the zero fragments the store masks away.
        if const_expr(not half_n):
            c01_frag = [Vec(fx.memref_load_vec(reg)) for reg in acc[1]]
    pair_col = block_n * BLOCK_N + wave_n_offset * 2

    def _store_row(frag_even, frag_odd, row):
        """One m half's quadrants, through the band writer that matches the atom's edge.
        ``half_n`` leaves column half 1 holding the zero fragments, so it is not stored."""
        halves = (frag_even, frag_odd)
        if const_expr(half_n):
            halves = (frag_even,)
        if const_expr(pair_cols):
            store_c.store_band_pair16(frag_even, frag_odd, row, pair_col, N_TILES_B, mask_cols=not col_safe)
        if const_expr(pair_tiles):
            # The live half's column tiles already alternate even/odd, so the pair is its j 0 against j 1.
            store_c.store_band_pair16(
                frag_even[0::2], frag_even[1::2], row, base_col, 1, mask_cols=not col_safe
            )
        if const_expr(merge_tile_pairs):
            store_band_merged16(
                store_c, halves, row, base_col, LDS_BLOCK_N, N_TILES_A, N_TILES_B, store_c.c_rows
            )
        if const_expr(not pair_cols and not pair_tiles and not merge_tile_pairs):
            store_c.store_band16(
                halves,
                row,
                base_col,
                LDS_BLOCK_N,
                N_TILES_A,
                N_TILES_B,
                store_c.c_rows,
                mask_n=not col_safe,
            )

    # m half 0 finalises early, so its stores issue under the remaining matrix work, past the drain.
    _store_row(c00_frag, c01_frag, base_row)

    a1_frag = a_s2r.load(a_cur1)
    rocdl.s_barrier()
    rocdl.sched_barrier(0)
    c10_frag = _mma(2, c10_frag, a1_frag, b0_frag)
    if const_expr(not half_n):
        c11_frag = _mma(3, c11_frag, a1_frag, b1_frag)
    rocdl.sched_barrier(0)
    rocdl.s_barrier()

    if const_expr(PRED):
        c10_frag = [Vec(fx.memref_load_vec(reg)) for reg in acc[2]]
        if const_expr(not half_n):
            c11_frag = [Vec(fx.memref_load_vec(reg)) for reg in acc[3]]

    _store_row(c10_frag, c11_frag, base_row + LDS_BLOCK_M)
    if const_expr(persistent == "staggered"):
        # pairs with the high half's last barrier: past it no wave reads this tile's LDS
        if WAVE_HI == 0:
            rocdl.s_barrier()


def gemm_bf16_nt_tile(
    A,
    B_T,
    C,
    c_m,
    c_n,
    lds,
    block_m=None,
    block_n=None,
    *,
    K,
    BLOCK_M,
    BLOCK_N,
    n_blocks=None,
    GROUP_M=1,
    num_xcd=8,
    persistent=False,
    ab_ty=fx.BFloat16,
    out_fp16=False,
    nt_vmcnt=3,
    b_group_base=None,
    c_cache_modifier=0,
    pair_n=False,
    n_tail=None,
    a_row_idx=None,
    store_c_cls=StoreCBf16,
    k_seg=None,
    k_ext=None,
    tid=None,
):
    """``k_ext=(A2, B2_T, K2)`` (optional) accumulates ``A2 @ B2_T^T`` (row stride ``K2``) after the
    first product, in the same K loop: one epilogue for ``C = A @ B_T^T + A2 @ B2_T^T``."""
    assert BLOCK_M >= 128 and BLOCK_N >= 256 and BLOCK_M % 128 == 0 and BLOCK_N % 256 == 0
    assert K % BLOCK_K == 0, f"bf16 NT needs K % {BLOCK_K} == 0 (got K={K})"
    N_TILES_A = BLOCK_M // 128
    N_TILES_B = BLOCK_N // 256
    LDS_BLOCK_M = BLOCK_M // 2
    LDS_BLOCK_N = BLOCK_N // 2
    N_LDS_STEPS_A = LDS_BLOCK_M // 64
    N_LDS_STEPS_B = LDS_BLOCK_N // 64
    N_LDS_ROUNDS = max(N_LDS_STEPS_A, N_LDS_STEPS_B)

    tid = fx.thread_idx.x if tid is None else tid
    lane_id = tid % 64
    wave_id = tid // 64
    wave_m = wave_id // 4
    wave_n = wave_id % 4
    # Two waves share a SIMD (``wave_id % 4``) and must share wave_n to read one B fragment.
    MAIN_GRID = (N_TILES_A, N_TILES_B, wave_m, wave_n)
    TAIL_GRID = (1, 1, wave_id // 2, wave_id % 2)

    if block_m is None:
        num_pid_m = ceildiv(c_m, BLOCK_M)
        pid = xcd_remap_pid(fx.block_idx.x, num_pid_m * n_blocks, num_xcd)
        num_pid_in_group = GROUP_M * n_blocks
        group_id = pid // num_pid_in_group
        pid_in_group = pid % num_pid_in_group
        first_pid_m = group_id * GROUP_M
        remaining_m = num_pid_m - first_pid_m
        group_size_m = arith.select(remaining_m < GROUP_M, remaining_m, fx.Int32(GROUP_M))
        block_m = first_pid_m + (pid_in_group % group_size_m)
        block_n = pid_in_group // group_size_m

    A0_gl_offset = (block_m * BLOCK_M) * K if a_row_idx is None else 0
    A1_gl_offset = (block_m * BLOCK_M + LDS_BLOCK_M) * K if a_row_idx is None else 0
    B0_gl_offset = (block_n * BLOCK_N) * K
    # Column-interleaved feed: LDS half 0/1 hold the block's even and odd output columns, paired at store.
    PAIR_COLS = pair_n and N_TILES_B == 1
    if b_group_base is not None:
        B0_gl_offset = B0_gl_offset + b_group_base

    gA = make_fp16_bf16_buffer_tensor(A)
    gB = make_fp16_bf16_buffer_tensor(B_T)
    a_div = fx.logical_divide(gA, fx.make_layout(1, 1))
    b_div = fx.logical_divide(gB, fx.make_layout(1, 1))

    gl_off_a = compute_global_swizzle_bf16(lane_id, wave_id, K, N_LDS_ROUNDS)
    gl_off_b = compute_global_swizzle_bf16(lane_id, wave_id, K, N_LDS_ROUNDS)

    # The g2s/LDS type only sizes the addressing (2 bytes either way); the operand format is
    # decided by the mfma atom, so fp16 rides the bf16 staging untouched.
    a_g2s = _make_a_g2s(a_div, gl_off_a, a_row_idx, lane_id, wave_id, K, N_LDS_STEPS_A, LDS_BLOCK_M)
    b_g2s = G2SLoader(b_div, gl_off_b, N_LDS_STEPS_B, fx.BFloat16.ir_type, wave_id)
    _out_ty = fx.Float16 if out_fp16 else fx.BFloat16
    store_c = store_c_cls(C, c_m, c_n, _out_ty, cache_modifier=c_cache_modifier)
    if k_ext is not None:
        A2, B2_T, K2 = k_ext
        assert K2 % BLOCK_K == 0 and a_row_idx is None and b_group_base is None
        a2_div = fx.logical_divide(make_fp16_bf16_buffer_tensor(A2), fx.make_layout(1, 1))
        b2_div = fx.logical_divide(make_fp16_bf16_buffer_tensor(B2_T), fx.make_layout(1, 1))
        a2_g2s = _make_a_g2s(
            a2_div,
            compute_global_swizzle_bf16(lane_id, wave_id, K2, N_LDS_ROUNDS),
            None,
            lane_id,
            wave_id,
            K2,
            N_LDS_STEPS_A,
            LDS_BLOCK_M,
        )
        b2_g2s = G2SLoader(b2_div, None, N_LDS_STEPS_B, fx.BFloat16.ir_type, wave_id)

    def _b_offsets(k_stride, pair_cols, pair_tiles):
        if pair_cols:
            return compute_global_swizzle_bf16(lane_id, wave_id, k_stride, N_LDS_ROUNDS, row_step=2)
        if pair_tiles:
            return compute_global_swizzle_bf16(lane_id, wave_id, k_stride, N_LDS_ROUNDS, pair_span=32)
        return compute_global_swizzle_bf16(lane_id, wave_id, k_stride, N_LDS_ROUNDS)

    def _run(pair_cols, grid, half_n, col_safe=False, b_steps=N_LDS_STEPS_B, pair_tiles=False):
        # The bodies differ only in B's column layout, so the loader is re-pointed, not duplicated.
        n_a, n_b, w_m, w_n = grid
        assert not pair_tiles or n_b == 1, "pair_tiles pairs a wave's two 16-column tiles"
        b_g2s.gl_offsets = gl_off_b if not (pair_cols or pair_tiles) else _b_offsets(K, pair_cols, pair_tiles)
        b_g2s.n_load_steps = b_steps
        ext = None
        if k_ext is not None:
            b2_g2s.gl_offsets = _b_offsets(K2, pair_cols, pair_tiles)
            b2_g2s.n_load_steps = b_steps
            b2_base = (block_n * BLOCK_N) * K2
            ext = _KExt(
                a_g2s=a2_g2s,
                b_g2s=b2_g2s,
                a_base=((block_m * BLOCK_M) * K2, (block_m * BLOCK_M + LDS_BLOCK_M) * K2),
                b_base=(b2_base, b2_base + (K2 if pair_cols else LDS_BLOCK_N * K2)),
                num_chunks=K2 // BLOCK_K,
            )
        n_a16, n_b16 = 2 * n_a, 2 * n_b
        dense_mma_pipeline_bf16(
            lds,
            a_g2s,
            b_g2s,
            S2RLoader16x16Bf16(w_m, n_a16),
            S2RLoader16x16Bf16(w_n, n_b16),
            Mfma16x16x32(n_a16, n_b16, ab_ty),
            store_c,
            A0_gl_offset,
            A1_gl_offset,
            B0_gl_offset,
            B0_gl_offset + (K if pair_cols else LDS_BLOCK_N * K),
            BLOCK_K,
            BLOCK_K,
            block_m,
            block_n,
            w_m,
            w_n,
            K,
            BLOCK_M,
            BLOCK_N,
            nt_vmcnt,
            pair_cols=pair_cols,
            pair_tiles=pair_tiles,
            half_n=half_n,
            n_tiles_a=n_a16,
            n_tiles_b=n_b16,
            wave_hi=wave_m,
            col_safe=col_safe,
            persistent=persistent,
            k_seg=k_seg,
            k_ext=ext,
        )

    TAIL_QUADS = 0 if n_tail is None else ceildiv(n_tail, 32)
    if TAIL_QUADS not in (2, 4):
        _run(PAIR_COLS, MAIN_GRID, False, n_tail == 0)
    else:
        tail_grid = TAIL_GRID if TAIL_QUADS == 2 else MAIN_GRID
        emit_if_then((block_n + 1) * BLOCK_N <= c_n, lambda: _run(PAIR_COLS, MAIN_GRID, False, True))
        emit_if_then(
            (block_n + 1) * BLOCK_N > c_n,
            lambda: _run(False, tail_grid, True, n_tail % 32 == 0, ceildiv(n_tail, 64), pair_tiles=pair_n),
        )


def _gemm_bf16_nn_tn_tile_impl(
    A,
    B,
    C,
    c_m,
    c_n,
    lds,
    block_m,
    block_n,
    *,
    a_transpose,
    K,
    BLOCK_M,
    BLOCK_N,
    n_blocks=None,
    GROUP_M=1,
    num_xcd=8,
    persistent=False,
    ab_ty=fx.BFloat16,
    out_fp16=False,
    nt_vmcnt=3,
    b_group_base=None,
    c_cache_modifier=0,
    n_tail=0,
    a_row_idx=None,
    pair_n=False,
    k_seg=None,
):
    assert BLOCK_M >= 128 and BLOCK_N >= 256 and BLOCK_M % 128 == 0 and BLOCK_N % 256 == 0
    assert K % BLOCK_K == 0, f"bf16 NN/TN needs K % {BLOCK_K} == 0 (got K={K})"
    assert not pair_n or not out_fp16, "merged row runs are built for bf16 output"
    assert a_row_idx is None or not a_transpose, "a_row_idx gathers rows of a row-major A"
    LDS_BLOCK_M = BLOCK_M // 2
    LDS_BLOCK_N = BLOCK_N // 2
    N_LDS_STEPS_A = LDS_BLOCK_M // 64
    N_LDS_STEPS_B = LDS_BLOCK_N // 64
    N_LDS_ROUNDS = max(N_LDS_STEPS_A, N_LDS_STEPS_B)
    NTA16 = LDS_BLOCK_M // 32
    NTB16 = LDS_BLOCK_N // 64
    assert NTA16 in (1, 2, 4) and NTB16 in (1, 2, 4), "a wave's tiles must not straddle a chunk group"

    lane_id = fx.thread_idx.x % 64
    wave_id = fx.thread_idx.x // 64
    wave_hi = wave_id // 4
    # Transposing it trades B's free tr16 read for A's dearer ds_read_b128 and loses.
    wave_n = wave_id % 4
    MAIN_GRID = (NTA16, NTB16, wave_hi, wave_n)
    TAIL_GRID = (2, 2, wave_id // 2, wave_id % 2)

    if block_m is None:
        num_pid_m = ceildiv(c_m, BLOCK_M)
        pid = xcd_remap_pid(fx.block_idx.x, num_pid_m * n_blocks, num_xcd)
        num_pid_in_group = GROUP_M * n_blocks
        group_id = pid // num_pid_in_group
        pid_in_group = pid % num_pid_in_group
        first_pid_m = group_id * GROUP_M
        remaining_m = num_pid_m - first_pid_m
        group_size_m = arith.select(remaining_m < GROUP_M, remaining_m, fx.Int32(GROUP_M))
        block_m = first_pid_m + (pid_in_group % group_size_m)
        block_n = pid_in_group // group_size_m

    if a_transpose:
        A0_gl_offset = block_m * BLOCK_M + 0
        A1_gl_offset = block_m * BLOCK_M + LDS_BLOCK_M
        a_k_step = BLOCK_K * c_m
    else:
        A0_gl_offset = (block_m * BLOCK_M) * K if a_row_idx is None else 0
        A1_gl_offset = (block_m * BLOCK_M + LDS_BLOCK_M) * K if a_row_idx is None else 0
        a_k_step = BLOCK_K
    B0_gl_offset = block_n * BLOCK_N + 0
    B1_gl_offset = block_n * BLOCK_N + LDS_BLOCK_N
    b_k_step = BLOCK_K * c_n
    if b_group_base is not None:
        B0_gl_offset = B0_gl_offset + b_group_base
        B1_gl_offset = B1_gl_offset + b_group_base

    gA = make_fp16_bf16_buffer_tensor(A)
    gB = make_fp16_bf16_buffer_tensor(B)
    a_div = fx.logical_divide(gA, fx.make_layout(1, 1))
    b_div = fx.logical_divide(gB, fx.make_layout(1, 1))
    if a_transpose:
        gl_off_a = compute_global_swizzle_nn_bf16_wide(lane_id, wave_id, c_m, N_LDS_STEPS_A)
    else:
        gl_off_a = compute_global_swizzle_bf16(lane_id, wave_id, K, N_LDS_ROUNDS)
    gl_off_b = compute_global_swizzle_nn_bf16_wide(lane_id, wave_id, c_n, N_LDS_STEPS_B)

    a_g2s = _make_a_g2s(a_div, gl_off_a, a_row_idx, lane_id, wave_id, K, N_LDS_STEPS_A, LDS_BLOCK_M)
    b_g2s = G2SLoader(b_div, gl_off_b, N_LDS_STEPS_B, fx.BFloat16.ir_type, wave_id)
    _out_ty = fx.Float16 if out_fp16 else fx.BFloat16
    store_c = StoreCBf16(C, c_m, c_n, _out_ty, cache_modifier=c_cache_modifier)

    def _run(grid, quad_conds, half_n, col_safe=False, b_steps=N_LDS_STEPS_B, merge_tile_pairs=False):
        n_a16, n_b16, w_m, w_n = grid
        b_g2s.n_load_steps = b_steps
        a_s2r = S2RLoaderTr16x32Bf16Wide(w_m, n_a16) if a_transpose else S2RLoader16x16Bf16(w_m, n_a16)
        dense_mma_pipeline_bf16(
            lds,
            a_g2s,
            b_g2s,
            a_s2r,
            S2RLoaderTr16x32Bf16Wide(w_n, n_b16),
            Mfma16x16x32(n_a16, n_b16, ab_ty),
            store_c,
            A0_gl_offset,
            A1_gl_offset,
            B0_gl_offset,
            B1_gl_offset,
            a_k_step,
            b_k_step,
            block_m,
            block_n,
            w_m,
            w_n,
            K,
            BLOCK_M,
            BLOCK_N,
            nt_vmcnt,
            quad_conds=quad_conds,
            half_n=half_n,
            n_tiles_a=n_a16,
            n_tiles_b=n_b16,
            wave_hi=wave_hi,
            col_safe=col_safe,
            persistent=persistent,
            merge_tile_pairs=merge_tile_pairs,
            k_seg=k_seg,
        )

    # Fork a ragged N on the workgroup-uniform column index: barriers stay matched and a feed half drops.
    TAIL_TILES = ceildiv(n_tail, 32)
    if n_tail == 0:
        _run(MAIN_GRID, None, False, True, merge_tile_pairs=pair_n)
    else:
        conds = _quad_col_conds(block_n * BLOCK_N + wave_n * (NTB16 * 16), LDS_BLOCK_N, c_n)
        half_n = n_tail <= LDS_BLOCK_N
        exact = n_tail % 32 == 0
        if TAIL_TILES == 2:
            tail = (TAIL_GRID, None, half_n, exact, ceildiv(n_tail, 64))
        else:
            tail = (MAIN_GRID, conds, half_n, False, N_LDS_STEPS_B)
        emit_if_then(
            (block_n + 1) * BLOCK_N <= c_n,
            lambda: _run(MAIN_GRID, None, False, True, merge_tile_pairs=pair_n),
        )
        emit_if_then((block_n + 1) * BLOCK_N > c_n, lambda: _run(*tail))


def gemm_bf16_nn_tile(
    A,
    B,
    C,
    c_m,
    c_n,
    lds,
    block_m=None,
    block_n=None,
    *,
    K,
    BLOCK_M,
    BLOCK_N,
    n_blocks=None,
    GROUP_M=1,
    num_xcd=8,
    persistent=False,
    ab_ty=fx.BFloat16,
    out_fp16=False,
    nt_vmcnt=3,
    b_group_base=None,
    c_cache_modifier=0,
    n_tail=0,
    a_row_idx=None,
    pair_n=False,
    k_seg=None,
):
    _gemm_bf16_nn_tn_tile_impl(
        A,
        B,
        C,
        c_m,
        c_n,
        lds,
        block_m,
        block_n,
        a_transpose=False,
        K=K,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        n_blocks=n_blocks,
        GROUP_M=GROUP_M,
        num_xcd=num_xcd,
        persistent=persistent,
        ab_ty=ab_ty,
        out_fp16=out_fp16,
        nt_vmcnt=nt_vmcnt,
        b_group_base=b_group_base,
        c_cache_modifier=c_cache_modifier,
        n_tail=n_tail,
        a_row_idx=a_row_idx,
        pair_n=pair_n,
        k_seg=k_seg,
    )


def gemm_bf16_tn_tile(
    A,
    B,
    C,
    c_m,
    c_n,
    lds,
    block_m=None,
    block_n=None,
    *,
    K,
    BLOCK_M,
    BLOCK_N,
    n_blocks=None,
    GROUP_M=1,
    num_xcd=8,
    persistent=False,
    ab_ty=fx.BFloat16,
    out_fp16=False,
    nt_vmcnt=3,
    b_group_base=None,
):
    _gemm_bf16_nn_tn_tile_impl(
        A,
        B,
        C,
        c_m,
        c_n,
        lds,
        block_m,
        block_n,
        a_transpose=True,
        K=K,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        n_blocks=n_blocks,
        GROUP_M=GROUP_M,
        num_xcd=num_xcd,
        persistent=persistent,
        ab_ty=ab_ty,
        out_fp16=out_fp16,
        nt_vmcnt=nt_vmcnt,
        b_group_base=b_group_base,
    )


def gemm_bf16_tile(layout, *args, **kwargs):
    # static layout dispatch: layout is a compile-time constant.
    # Grouped callers rebase A/C into per-tile views (via make_bf16_fp16_tile_tensor)
    # before calling, so every impl's API stays unchanged here.
    if layout == "nt":
        return gemm_bf16_nt_tile(*args, **kwargs)
    if layout == "nn":
        return gemm_bf16_nn_tile(*args, **kwargs)
    if layout == "tn":
        return gemm_bf16_tn_tile(*args, **kwargs)
    raise ValueError(f"unsupported layout {layout}")
